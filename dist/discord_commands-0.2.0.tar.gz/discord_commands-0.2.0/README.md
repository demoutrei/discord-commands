Command Types:
1. Reply commands


Credits for the command [ideas](<https://gist.github.com/Soheab/a6229dbbe3acf3ce9a4625bf9e7177da>):
- [Soheab](<https://github.com/Soheab>)
- [maukkis](<https://github.com/maukkis>)